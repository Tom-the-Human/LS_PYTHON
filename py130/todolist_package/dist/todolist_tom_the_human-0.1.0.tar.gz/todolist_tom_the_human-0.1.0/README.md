Tom's todolist.py project from the Launch School curriculum.

Unless it continues to recieve significant updates, it will not likely be of much interest to anyone outside of Launch School.

Or perhaps you're interested in hiring me to write software, in which case you might be interested to see that I can do at least this much (and more).